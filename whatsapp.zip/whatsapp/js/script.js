$(document).ready(function(){
	$(".menu-button").click(function(e){
		if($("#menu-box").is(":hidden")){
			$("#menu-box").show();
		} else{
			$("#menu-box").hide();
		}
		e.stopPropagation();
	});
	$("body").click(function(event){
		// alert("sdgfg")
		if($("#menu-box").is(":visible")){
			$("#menu-box").hide();
		}
	})
	$(".list-content1").contextmenu(function(){
		if($("#menu-box2").is(":hidden")){
			$("#menu-box2").show();
		} else{
			$("#menu-box2").hide();
		}
	});
	$(".chat-button").click(function(){
		
			$(".contacts-page").animate({
			width:"toggle"
		});
			$("#menu-box").hide();
});
	$(".newchatarrowbutton").click(function(){
		
			$(".contacts-page").animate({
			width:"toggle"
		});
});
	$(".status-button").click(function(){
		
			$(".status-page-full").animate({
			width:"toggle"
		});
		$("#menu-box").hide();
});
	$(".wrong").click(function(){
		
			$(".status-page-full").animate({
			width:"toggle"
		});
});
	$(".dp").click(function(){
		
			$(".profile-page").animate({
			width:"toggle"
		});
		$("#menu-box").hide();
});
	$(".profilearrowbutton").click(function(){
		
			$(".profile-page").animate({
			width:"toggle"
		});
});
	$(".settings").click(function(){
		
			$(".settings-page").animate({
			width:"toggle"
		});
			$("#menu-box").hide();
});
	$(".settingsarrowbutton").click(function(){
		
			$(".settings-page").animate({
			width:"toggle"
		});
});
	$(".settings-profile").click(function(){
		
			$(".profile-page").animate({

			width:"toggle"
		});
});
	$(".profile").click(function(){
		
			$(".profile-page").animate({
			width:"toggle"
		});
			$("#menu-box").hide();
});
	
	$(".notificationsarrowbutton").click(function(){
		
			$(".settings-page").animate({
			width:"toggle"
		});
			$(".notification-page").hide();
});
	$(".profile-list-content0").click(function(){
		
			$(".notification-page").animate({
			width:"toggle"
		});
			$("#menu-box").hide();
});
	$(".list-contents").click(function(){
			
			$("#right-side").hide();
			$(".chat-page").show();

		// 	$(".chat-page").animate({
		// 	width:"toggle"
		// });
});
	$(".list-contents").click(function(){
		if($("#right-side").is(":hidden")){
			$(".chat-page").show();
		} else{
			$(".chat-page").hide();
		}
	});


	$(".list-contents").click(function(){
		var image=$(this).find("img").prop('src');
		var name=$(this).find("h4").html();
		$(".chat-header-content1>img").attr('src',image);
		$(".dp-name>h5").html(name);
	});
});

	